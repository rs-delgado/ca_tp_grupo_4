# Mostrar ayuda
if [ "$1" = "-help" ] || [ $# -ne 2 ]; then
    echo "=============================================="
    echo "           BACKUP_FULL.SH - AYUDA"
    echo "=============================================="
    echo ""
    echo "USO:"
    echo "  $0 [directorio_origen] [directorio_destino]"
    echo ""
    echo "=============================================="
    exit 0
fi

# Variables
ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +"%Y%m%d")

if [ ! -d "$ORIGEN" ]; then
    echo "ERROR: Directorio origen '$ORIGEN' no existe"
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "ERROR: Directorio destino '$DESTINO' no existe"
    exit 1
fi

if [ -z "$(ls -A "$ORIGEN")" ]; then
    echo "ERROR: El archivo/directorio '$ORIGEN' está vacío"
    exit 1
fi

# Generar nombre de backup
NOMBRE_DIR=$(basename "$ORIGEN")
BACKUP_NAME="${NOMBRE_DIR}_bkp_${FECHA}"

BACKUP_FILE="${DESTINO}/${BACKUP_NAME}.tar.gz"  

# Crear backup
echo "Creando backup: $BACKUP_FILE"
echo "Origen: $ORIGEN"

if tar -cf "$BACKUP_FILE" "$ORIGEN"; then
    echo "Creando archivo tar"
    if gzip "$BACKUP_FILE"; then
        LENG=$(du -h "$BACKUP_FILE" | cut -f1)
        echo "SUCCESS: Backup completado - Tamaño: $LENG"
        exit 0
    else
        echo "ERROR: Fallo la compresion"
        exit 1
    fi
else
    echo "ERROR: Falló la creación del backup"
    exit 1
fi
